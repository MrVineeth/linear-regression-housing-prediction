# Linear Regression - Housing Price Prediction

This project implements a simple linear regression model using the **House Price Prediction** dataset.

## Dataset
- Used sample housing dataset (`area` vs `price`).
- [Kaggle Dataset](https://www.kaggle.com/datasets/harishkumardatalab/housing-price-prediction)

## Steps
1. Load and preprocess the dataset
2. Apply Linear Regression using Scikit-learn
3. Evaluate with MAE, MSE, and R² score
4. Plot regression line
5. Interpret model coefficients

## Results
- MAE, MSE, and R² are printed
- Regression line plotted using matplotlib

## Tools Used
- Python
- Pandas
- Scikit-learn
- Matplotlib

## Screenshot
Plot is saved as `regression_plot.png` in the folder.

---

✅ Task ready to be submitted via GitHub.
